

Starting with sorting integers with a random data set selection sort is faster than bubble sort and merge sort when the array is less than 1000. 
When the array size is 1000 merge sort is faster than selection by a difference of 79ms. Merge sort runs faster when the array size is equal to or greater than 1000. 
Bubble sort as a time complexity of O(n) in the best case, and O(n^2) as the worst case showing how inefficient it is. 
The runtime complexity of selection sort is O(n^2) which makes it efficient when the array is already sorted. The runtime of merge sort is O(nlog(n)) which divides an 
array in half and merges the two halves, regardless of the order of the elements. Merge sort is also stable, which means the elements of the same value are ordered in 
the sorted list. 

When sorting doubles with a random set the times that was noticed when sorting regular integers is not the same when sorting doubles.
 Merge sort was the slowest from array size 100-5000. Selection sort was the fastest from array 100-10000. Merge sort took a drop in time from size 5000 to size 50000, 
 which didn't happen at all when sorting integers. When looking at merge sort the time actually decreases from size 5000 to size 50000, and it increased at the last 
 size of the array for the speed. This is due to the fact that my laptop was reaching pass its threshold.
